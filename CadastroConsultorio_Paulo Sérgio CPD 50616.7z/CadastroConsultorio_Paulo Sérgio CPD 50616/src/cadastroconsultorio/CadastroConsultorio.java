
package cadastroconsultorio;

import java.util.ArrayList;
import javax.swing.JOptionPane;


public class CadastroConsultorio {

    //cria as listas para guardar as informações
    static ArrayList<Medico> medicos = new ArrayList<Medico>();
    static ArrayList<Paciente> pacientes = new ArrayList<Paciente>();
    static ArrayList<Consulta> consultas = new ArrayList<Consulta>();
    static ArrayList<Nota> notas = new ArrayList<Nota>();
    static ArrayList<String> pesquisa = new ArrayList<String>();
    static ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
    static ArrayList<Login> logins = new ArrayList<Login>();
    //cria as listas 

    //variaveis estaticas das classes medico , paciente, consulta e nota
    static Medico medico = new Medico();
    static Paciente paciente = new Paciente();
    static Consulta consulta = new Consulta();
    static Nota nota = new Nota();
    // variaveis estaticas das classes dos atributos medico , paciente, consulta e nota
    static int lista;
    static int acho;
    static int crm;
    static int codigoNota;
    static int numeroCpf;
    static int codigoConsulta;
    static String data;
    private static int codigo;
    private static String nomMed;
    private static String password;
    private static String userName;
    //fim - variaveis estaticas

    public static void main(String[] args) {

        cadastroUsuario(); // Verificador -  Cadastro de usuario referente ao login para ter acesso ao Menu. O usuario so consegue
        //entrar no menu apos inserir o nome de usuario e a senha.
        int i = 0;

        //Vai precisar duplicar a chamada num if:
        if ((usuarios.get(i).getUserName() == null ? logins.get(i).getUserNameLogar() == null : usuarios.get(i).getUserName().equals(logins.get(i).getUserNameLogar()))) {

            if (usuarios.get(i).getPassword() == null ? logins.get(i).getPasswordLogar() == null : usuarios.get(i).getPassword().equals(logins.get(i).getPasswordLogar())) {

                JOptionPane.showMessageDialog(null, usuarios.get(i).getUserName() + "\nLogado com sucesso.", "Aviso\n", 1);
            }

            menu();

        } else {

            JOptionPane.showMessageDialog(null, "User Name ou Password Invalodos.", "Aviso", 1);
            cadastroUsuario();

        }

        //Fim - verificador Verificador Cadastro de usuario referente ao login para ter acesso ao Menu
        
        //Menu com todas as metodos da classes
        lista = 1;

        while (true) {
            switch (lista) {
                case 1:
                    cadastroMedico();
                    break;

                case 2:
                    listarMedico();
                    break;

                case 3:
                    cadastroPaciente();
                    break;

                case 4:
                    listarPaciente();
                    break;

                case 5:
                    cadastroConsulta();
                    break;

                case 6:
                    listarConsulta();
                    break;

                case 7:
                    notaConsulta();
                    break;

                case 8:
                    listarNota();
                    break;

                case 9:
                    menu();
                    break;

                case 10:
                    sair();

                    break;
                default:
                    JOptionPane.showMessageDialog(null, "OPÇÃO INVALIDA!!!", "Aviso", 1);
                    menu();

            }
        }
    }
    // Fim do Menu

    public static void menu() { // metodo do Menu com o JOptionPane
        lista = 1;
        lista = Integer.parseInt(JOptionPane.showInputDialog(null, "MENU:\n\n1. Cadastrar o Médico\n2. Listar Medicos\n3. Cadastrar o Paciente\n4. listar Pacientes\n5. Cadastrar a Consulta"
                + "\n6. Listar consulta\n7. Avaliar consulta \n8. Listar Notas\n9. Voltar\n10. Sair\n\nDigite a opção:"));

    }

    // Tela para o cadastro do medico---------------------------------------------------------------------------------------------------------------------------------------------------------------
    public static void cadastroMedico() {

        //desclara as variaveis da classe Medico
        String nomeMedico;
        String especializacao;
        String nacionalidade;
        String sexo;
        String idade;
        String telefone;
        String email;
        //opcao
        int lista = 1;

        //verifica se o codigo do medico já existe
        do { // começo do laço de repetição 
            acho = 0;

            //Verifica se digitou somente numeros 
            int option = 0;
            while (option <= 0) {

                try { // foi utilizado o try / catch para o caso do usuario digitar alguma o sistema informar a mensagem abaixo
                    crm = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CRM do médico"));
                    option = crm;
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Informe apenas números");
                }
            }
            //verifica se digitou somente numeros se estiver digitado letra o sistema informa que o campo é somente numeros

            if (medicos.size() > 0) { //Size tamanho do arraylist do medico
                for (int i = 0; i < medicos.size(); i++) {
                    if (crm == medicos.get(i).getCrm()) {
                        acho = 1;
                    }
                }
            }
            if (acho == 1) { //Se o usuario digitar um medico ja cadastrado o sistema irar informar que ja consta cadastro
                JOptionPane.showMessageDialog(null, "Médico já cadastrado", "Aviso", 1);
            }
        } while (acho == 1); // Fim do laço de repetição
        //Fim - verifica se o codigo já existe se ja existe ele pede para que seja cadastrado outro medico

        //Menu para o usuario digitar os atributos do medico
        nomeMedico = JOptionPane.showInputDialog(null, "Digite o nome do médico: ");
        especializacao = JOptionPane.showInputDialog(null, "Digite a especializacao do médico: ");
        nacionalidade = JOptionPane.showInputDialog(null, "Digite a nacionalidade do médico: ");
        sexo = JOptionPane.showInputDialog(null, "Digite o sexo do médico: ");
        idade = JOptionPane.showInputDialog(null, "Digite a idade do médico: ");
        telefone = JOptionPane.showInputDialog(null, "Digite o numero de contato do médico: ");
        email = JOptionPane.showInputDialog(null, "Digite o email do médico: ");
        //Fim

        //Adiciona os valores no arraylist
        medicos.add(new Medico(crm, nomeMedico, especializacao, nacionalidade, sexo, idade, telefone, email));

        //opcao Menu para fazer cadastro do medico
        // utilizei o Integer na lista transforma uma String em Int
        lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja efetuar outro cadastro de médico?\n1. Sim\n7. Não"));
        if (lista == 1) { //para cadastrar novo medico
            cadastroMedico();
        } else if (lista == 7) { // volta para o menu
            menu();
        }
    }

    public static void listarMedico() { // Metodo para listar todos os medicos que foram cadastrados

        //declarei a variavel medico2 pois eu não poderia usar com o numero do medico 
        String medicos2 = "";
        String codigoDelete = null;
        String linha3 = "";

        String especializacao2 = "";
        String nacionalidade2 = "";
        String sexo2 = "";
        String idade2 = "";
        String telefone2 = "";
        String email2 = "";

        String codigo4 = "CRM: ";
        String codigo3 = "";
        //Fim - declaração das variaveis

        //caso eu tenha medicos cadastrado vai percorrer toda a arraylist para verificação 
        if (medicos.size() > 0) {
            for (int i = 0; i < medicos.size(); i++) {

                //coloca os valores na variavel
                codigo3 = Integer.toString(medicos.get(i).getCrm()); //retorna uma string equivalente ao valor desse inteiro. Este método fornece o mesmo resultado que Integer.toString (int i) . Ele substitui o método toString () da classe Object.
                medicos2 = " - Medico: " + medicos.get(i).getNomeMedico();

                especializacao2 = " - Especialização: " + medicos.get(i).getEspecializacao();
                nacionalidade2 = " - Nacionalidade: " + medicos.get(i).getNacionalidade();
                sexo2 = " - Sexo: " + medicos.get(i).getSexo();
                idade2 = " - Idade: " + medicos.get(i).getIdade();
                telefone2 = " - Telefone: " + medicos.get(i).getTelefone();
                email2 = " - Email: " + medicos.get(i).getEmail();
                //Fim - armazena os valores na variavel

                //Monta a lista de registros
                linha3 += codigo4 + codigo3 + medicos2 + especializacao2 + nacionalidade2 + sexo2 + idade2 + telefone2 + email2 + "\n";
                //linha 3 estou atribuindo Fim - monta a lista de registros

            }

            //menu caso o usurio deseja deletar, Editar ou sair do 
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, linha3 + "\n8. Deletar\n9. Editar\n7. Sair"));
            if (lista == 8) { // se a opção do usuario for 8 ele irar deletar o medico
                deletarMedico();
            } else if (lista == 9) { // se a opção do usuario for 9 ele irar fazer um update no cadastro do medico
                updateMedico();
            } else if (lista == 7) { //se a opção do usuario for 9 ele irar voltar ao menu principal
                menu();
            }

            //caso não  tenha nenhum medico cadstrado o sistema ira informar ue não existe medico cadastrado e se desseja cadastrar
        } else {

            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Não existe nenhum medico cadastrado, deseja cadastrar?\n1. Sim\n7. Não"));
            if (lista == 2) { //se a opção do usuario for 2 ele irar fazer o cadastro do medico
                cadastroMedico();
            } else if (lista == 7) { //se a opção do usuario for 7 ele irar voltar para a tela do menu principal
                menu();
            }
        }
    }

    public static void deletarMedico() { //Metodo para deletar o medico que ja foi cadastrado

        //pega o variavel  do codigo medico
        int codigoMedico2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CRM do medico a ser deletado:"));

        //verifica se existe medico cadastrado
        if (medicos.size() > 0) {
            for (int i = 0; i < medicos.size(); i++) {

                if (medicos.get(i).getCrm() == (codigoMedico2)) {

                    medicos.remove(i); // exclui o medico
                    JOptionPane.showMessageDialog(null, "Registro deletado com Sucesso", "Aviso", 1); //Avisa que o  medico ja foi removido

                }

            }

            //menu com a informação se deseja deletar outro registro cadastrado
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja deletar outro registro\n1. Sim\n2. Não"));
            if (lista == 1) { // se a opção do usuario for 1 abre o tela para a exclusão do medico
                deletarMedico();
            } else if (lista == 7) { //se a opção do usuario for 7 volta ao menu principal
                menu();
            }

        } else {

            menu();

        }
    }

    public static void updateMedico() { // metodo de fazer a atualização do medico

        //pega o valor do codigo do medico e atribui a variavel
        int codigoMedico4 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CRM do medico a Editar:"));

        //verifica se exixte medicos para serem feitos as atualizações
        if (medicos.size() > 0) {
            for (int i = 0; i < medicos.size(); i++) {

                //para no registro do codigo
                if (medicos.get(i).getCrm() == (codigoMedico4)) {

                    //pega os valores a atualizar
                    int codigoMedicoNovo4 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o novo CRM do medico:", codigoMedico4));
                    String nomeMedicoNovo4 = JOptionPane.showInputDialog(null, "Digite o novo Nome:", medicos.get(i).getNomeMedico());

                    String especializacao2 = JOptionPane.showInputDialog(null, "Digite a especializacao do médico: ", medicos.get(i).getEspecializacao());
                    String nacionalidade2 = JOptionPane.showInputDialog(null, "Digite a nacionalidade do médico: ", medicos.get(i).getNacionalidade());
                    String sexo2 = JOptionPane.showInputDialog(null, "Digite o sexo do médico: ", medicos.get(i).getSexo());
                    String idade2 = JOptionPane.showInputDialog(null, "Digite a idade do médico: ", medicos.get(i).getIdade());
                    String telefone2 = JOptionPane.showInputDialog(null, "Digite o contato do médico: ", medicos.get(i).getTelefone());
                    String email2 = JOptionPane.showInputDialog(null, "Digite o email do médico: ", medicos.get(i).getEmail());
                    //realiza o update nos registros que foram atualizados
                    medicos.get(i).setNomeMedico(nomeMedicoNovo4);
                    medicos.get(i).setCrm(codigoMedicoNovo4);
                    medicos.get(i).setEspecializacao(especializacao2);
                    medicos.get(i).setNacionalidade(nacionalidade2);
                    medicos.get(i).setSexo(sexo2);
                    medicos.get(i).setIdade(idade2);
                    medicos.get(i).setTelefone(telefone2);
                    medicos.get(i).setEmail(email2);
                    //tela com a mensagem de sucesso na atualização.
                    JOptionPane.showMessageDialog(null, "Registro Editado com Sucesso", "Aviso", 1);

                }
            }

            // Tela com a informação se deseja editar outro registro
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja editar outro registro\n1. Sim\n2. Não"));
            if (lista == 1) { //se a opção do usuario for 1 ele irar deletar o medito
                deletarMedico();
            } else if (lista == 7) { //se a opção do usuario for 7 ele irar voltar ao menu principal
                menu();
            }

        } else {

            menu();
        }

    }
    //Fim - cadastro, update, exclusão, remoção do medico-----------------------------------------------------------------------------------------------------------------------------------------------------------------

    // metodo cadastrar paciente-----------------------------------------------------------------------------------------------------------------------------------------------------------------
    public static void cadastroPaciente() {

        //declara as variaveis atribuidas ao paciente
        String nomePaciente;
        String rg;
        String endereco;
        String sexo;
        String idade;
        String tipoDoenca;
        String cidade;
        String telefone;
        String email;

        int lista = 1; // verifica se a lista é igual a 1

        acho = 0;

        //digita para verifica se existe o codigo cadastrado do paciente
        do {

            //atribuição para que seja somente digitado numeros ao CPF do paciente
            int option = 0;
            while (option <= 0) {

                try {
                    numeroCpf = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CPF do paciente"));
                    option = numeroCpf;
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Informe apenas números");
                }
            }

            if (pacientes.size() > 0) {
                for (int i = 0; i < pacientes.size(); i++) {
                    if (numeroCpf == pacientes.get(i).getNumeroCpf()) {
                        acho = 1;
                    }
                }
            }
            if (acho == 1) { // se a variavel acho for igual a 1 ja consta um paciente cadastrado com o cpf
                JOptionPane.showMessageDialog(null, "Paciente já cadastrado", "Aviso", 1);
            }
        } while (acho == 1);

        //pega so os valores e atribue as variaveis paciente
        nomePaciente = JOptionPane.showInputDialog(null, "Digite o nome do paciente: ");
        rg = JOptionPane.showInputDialog(null, "Digite o RG do paciente: ");
        sexo = JOptionPane.showInputDialog(null, "Digite o sexo do paciente: ");
        idade = JOptionPane.showInputDialog(null, "Digite a idade do paciente: ");
        tipoDoenca = JOptionPane.showInputDialog(null, "Digite o tipo de doença do paciente: ");
        endereco = JOptionPane.showInputDialog(null, "Digite o endereço do paciente: ");
        cidade = JOptionPane.showInputDialog(null, "Digite a cidade do paciente: ");
        telefone = JOptionPane.showInputDialog(null, "Digite o telefone de contato do paciente: ");
        email = JOptionPane.showInputDialog(null, "Digite o email do paciente: ");
        //adiciona as variaveis declarada a lista dos pacientes
        pacientes.add(new Paciente(numeroCpf, nomePaciente, rg, sexo, idade, tipoDoenca, endereco, cidade, telefone, email));

        //menu tela paciente
        lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja efetuar outro cadastro de paciente?\n1. Sim\n7. Não"));
        if (lista == 1) { //se a opção do usuario for 1 ele cadastra outro paciente
            cadastroPaciente();
        } else if (lista == 7) { //se a opção do usuario for 7 ele volta a tela do menu principal
            menu();
        }
    }
    // Metodo para mostrar os pacientes cadastrado

    public static void listarPaciente() {

        //cria as variaveis paciente
        String pacientes2 = "";
        String codigoDelete = null;
        String linha3 = "";

        String codigo4 = "Codigo: ";
        String codigo3 = "";

        String rg2 = null;
        String sexo2 = null;
        String idade2 = null;
        String tipoDoenca2 = null;
        String endereco2 = null;
        String cidade2 = null;
        String telefone2 = null;
        String email2 = null;
        //Fim - criação das variaveis do paciente

        //verifica se existe pacientes cadastrados
        if (pacientes.size() > 0) {
            for (int i = 0; i < pacientes.size(); i++) {

                //atribui os valores nas variaveis
                codigo3 = Integer.toString(pacientes.get(i).getNumeroCpf());
                pacientes2 = " - Paciente: " + pacientes.get(i).getNomePaciente();

                rg2 = " - RG: " + pacientes.get(i).getRg();
                sexo2 = " - Sexo: " + pacientes.get(i).getSexo();
                idade2 = " - Idade: " + pacientes.get(i).getIdade();
                tipoDoenca2 = " - Tipo Doença: " + pacientes.get(i).getTipoDoenca();
                endereco2 = " - Endereço: " + pacientes.get(i).getEndereco();
                cidade2 = " - Cidade: " + pacientes.get(i).getCidade();
                telefone2 = " - Numero de contato: " + pacientes.get(i).getTelefone();
                email2 = " - Email: " + pacientes.get(i).getEmail();
                //Fim - atribuição dos valores nas variaveis
                //Monta a lista de registros do paciente com as variaveis declarada
                linha3 += codigo4 + codigo3 + pacientes2 + rg2 + sexo2 + idade2 + tipoDoenca2 + endereco2 + cidade2 + telefone2 + email2 + "\n";
                //linha 3 estou atribuindo Fim - monta a lista de registros do paciente
            }

            //menu da lista do paciente com a opção de Deletar , Editar e sair.
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, linha3 + "\n8. Deletar\n9. Editar\n7. Sair"));
            if (lista == 8) {   //Se a opção do ususario for 8 ele vai deletar o paciente
                deletarPaciente();
            } else if (lista == 9) {
                updatePaciente(); //Se a opção do ususario for 9 ele irar fazer a atualização na lista paciente
            } else if (lista == 7) { //Se a opção do ususario for 7 ele irar voltar ao menu principal
                menu();
            }

        } else {

            //Menu caso não exista nenhum paciente cadastrado iara abrir o menu perguntando se deseja cadastrar paciente ou não  
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Não exiete nenhum paciente cadastrado, deseja cadastrar?\n1. Sim\n7. Não"));
            if (lista == 2) { //Se a opção do ususario for 2 ele irar abrir a tela para cadastrar o paciente
                cadastroPaciente();
            } else if (lista == 7) { //Se a opção do ususario for 7 ele irar voltar ao menu principal
                menu();
            }
        }
    }

    public static void deletarPaciente() { // Metodo para deletar o paciente

        //atribui o valor a variavel 
        int codigoPaciente2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CPF do paciente a ser deletado:"));

        if (pacientes.size() > 0) {
            for (int i = 0; i < pacientes.size(); i++) {

                if (pacientes.get(i).getNumeroCpf() == (codigoPaciente2)) {
                    //mensagem de sucesso se for deletado o paciente
                    pacientes.remove(i);
                    JOptionPane.showMessageDialog(null, "Registro deletado com Sucesso", "Aviso", 1);

                }

            }
            //menu
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja deletar outro registro\n1. Sim\n2. Não"));
            if (lista == 1) {
                deletarPaciente();
            } else if (lista == 7) {
                menu();
            }

        } else {

            menu();

        }

    }

    public static void updatePaciente() {
        //atribui o valor a variavel
        int numeroCpf4 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CPF do paciente a Editar:"));

        //caso tiver paciente cadastrado 
        if (pacientes.size() > 0) {
            for (int i = 0; i < pacientes.size(); i++) {

                if (pacientes.get(i).getNumeroCpf() == (numeroCpf4)) {

                    int numeroCpfNovo4 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o novo CPF:", numeroCpf4));
                    String nomePacienteNovo4 = JOptionPane.showInputDialog(null, "Digite o novo Nome:", pacientes.get(i).getNomePaciente());

                    String rg = JOptionPane.showInputDialog(null, "Digite o novo RG do paciente: ", pacientes.get(i).getRg());
                    String sexo = JOptionPane.showInputDialog(null, "Digite o novo sexo do paciente: ", pacientes.get(i).getSexo());
                    String idade = JOptionPane.showInputDialog(null, "Digite a nova idade do paciente: ", pacientes.get(i).getIdade());
                    String tipoDoenca = JOptionPane.showInputDialog(null, "Digite o tipo de doença do paciente: ", pacientes.get(i).getTipoDoenca());
                    String endereco = JOptionPane.showInputDialog(null, "Digite o novo endereço do paciente: ", pacientes.get(i).getEndereco());
                    String cidade = JOptionPane.showInputDialog(null, "Digite a nova cidade do paciente: ", pacientes.get(i).getCidade());
                    String telefone = JOptionPane.showInputDialog(null, "Digite o novo numerto contato do paciente: ", pacientes.get(i).getTelefone());
                    String email = JOptionPane.showInputDialog(null, "Digite o novo email do paciente: ", pacientes.get(i).getEmail());

                    pacientes.get(i).setNomePaciente(nomePacienteNovo4);
                    pacientes.get(i).setNumeroCpf(numeroCpfNovo4);

                    pacientes.get(i).setRg(rg);
                    pacientes.get(i).setSexo(sexo);
                    pacientes.get(i).setIdade(idade);
                    pacientes.get(i).setTipoDoenca(tipoDoenca);
                    pacientes.get(i).setEndereco(endereco);
                    pacientes.get(i).setCidade(cidade);
                    pacientes.get(i).setTelefone(telefone);
                    pacientes.get(i).setEmail(email);

                    JOptionPane.showMessageDialog(null, "Registro Editado com Sucesso", "Aviso", 1);

                }
            }

            //menu
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja editar outro registro\n1. Sim\n4. Não"));
            if (lista == 1) {
                deletarPaciente();
            } else if (lista == 7) {
                menu();
            }

        } else {
            //menu
            menu();

        }

    }
    //Fim - Cadastro , exclusão, alteracao do Paciente-----------------------------------------------------------------------------------------------------------------------------------------------------------------

    //Consulta-----------------------------------------------------------------------------------------------------------------------------------------------------------------
    public static void cadastroConsulta() {

        int lista = 1;
        //verifica se o codigo existe
        int crm2 = 0;
        do {
            acho = 0;
            codigoConsulta = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o código da consulta"));
            if (consultas.size() > 0) {
                for (int i = 0; i < consultas.size(); i++) {
                    if (codigoConsulta == consultas.get(i).getCodigoConsulta()) {
                        acho = 1;
                    }
                }
            }
            if (acho == 1) {
                JOptionPane.showMessageDialog(null, "Médico já cadastrado", "Aviso", 1);
            }
        } while (acho == 1);

        //pega os valores
        int codigoPaciente2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CPF do Paciente"));
        int crm3 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CRM do Medico"));
        String data3 = JOptionPane.showInputDialog(null, "Digite a data da consulta: ");
        String validade3 = JOptionPane.showInputDialog(null, "Digite a validade da consulta: ");
        String prescricao3 = JOptionPane.showInputDialog(null, "Digite a prescricao da consulta: ");
        String valorConsulta = JOptionPane.showInputDialog(null, "Digite o valor da consulta: ");

        //adiciona na lista
        consultas.add(new Consulta(codigoConsulta, crm3, codigoPaciente2, data3, validade3, prescricao3, valorConsulta));

        lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja efetuar outro cadastro de consulta?\n5. Sim\n7. Não"));
        if (lista == 5) {
            cadastroConsulta();
        } else if (lista == 7) {
            menu();
        }
    }

    public static void listarConsulta() { //Metodo para a listagem das consultas

        //cria as variaveis da lista de consultas
        String codigo4 = "Codigo: ";
        String codigo3 = "";
        String data2 = "";
        String linha3 = "";
        String nomePaciente3 = "";
        String nomeMedico3 = "";
        String prescricao = "";
        String validade = "";
        String valorConsulta = "";
        //caso existe colsultas 
        if (consultas.size() > 0) {
            for (int i = 0; i < consultas.size(); i++) {

                codigo3 = Integer.toString(consultas.get(i).getCodigoConsulta());
                valorConsulta = " - Valor Consulta: " + consultas.get(i).getValorConsulta();
                data2 = " - Data: " + consultas.get(i).getData();
                prescricao = " - Prescricao: " + consultas.get(i).getPrescricao();
                validade = " - Validade: " + consultas.get(i).getValidade();

//buscas todos os pacientes
                for (int a = 0; a < pacientes.size(); a++) {

                    int numeroCpf3 = (consultas.get(i).getPaciente());

                    if (pacientes.get(a).getNumeroCpf() == numeroCpf3) {

                        nomePaciente3 = pacientes.get(a).getNomePaciente();
                    }
                }
                //buscas todos os medicos cadastrados para a realização da consulta
                for (int a = 0; a < medicos.size(); a++) {

                    int crm3 = (consultas.get(i).getMedico());

                    if (medicos.get(a).getCrm() == crm3) {

                        nomeMedico3 = medicos.get(a).getNomeMedico();

                    }
                }

                //monta a lista de consulta  do medico que irar atender o paciente 
                linha3 += codigo4 + codigo3 + data2 + prescricao + validade + " Medico: " + nomeMedico3 + " Paciente: " + nomePaciente3 + " Consulta: " + valorConsulta + "\n";

            }
            //Menu com a informação ao usuario se deseja Deletar, Editar ou sair
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, linha3 + "\n8. Deletar\n9. Editar\n7. Sair"));
            if (lista == 8) { // Se a opção escolhida pelo usuario for 8 ele irar deletar a consulta
                deletarConsulta();
            } else if (lista == 9) { //Se a opção escolhida pelo usuario for 9 ele irar fazer a atualização  da consulta
                updateConsulta();
            } else if (lista == 7) { //Se a opção escolhida pelo usuario for 7 ele voltara ao menu principal
                menu();
            }

            //caso não haja consultas cadastradas
        } else {

            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Não exiete nenhum consulta cadastrado, deseja cadastrar?\n6. Sim\n7. Não"));
            if (lista == 6) {
                cadastroConsulta();
            } else if (lista == 7) {
                menu();
            }
        }
    }

    public static void deletarConsulta() { //Metodo para deletar as consultas

        int codigoConsulta2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o codigo do consulta a ser deletado:"));

        if (consultas.size() > 0) {
            for (int i = 0; i < consultas.size(); i++) {

                if (consultas.get(i).getCodigoConsulta() == (codigoConsulta2)) {

                    consultas.remove(i);
                    JOptionPane.showMessageDialog(null, "Registro deletado com Sucesso", "Aviso", 1);

                }
            }

            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja deletar outro registro\n8. Sim\n6. Não"));
            if (lista == 8) {
                deletarConsulta();
            } else if (lista == 6) {
                listarConsulta();
            }

        } else {

            menu();

        }
    }

    public static void updateConsulta() { //metodo para fazer a atualização das consultas

        int codigoConsulta4 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o codigo do consulta a Editar:"));

        if (consultas.size() > 0) {
            for (int i = 0; i < consultas.size(); i++) {

                if (consultas.get(i).getCodigoConsulta() == (codigoConsulta4)) {

                    int codigoConsultaNovo4 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o novo codigo:", codigoConsulta4));
                    int crm2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o novo CRM do medico", consultas.get(i).getMedico()));
                    int codigoPaciente2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o CPF do paciente", consultas.get(i).getPaciente()));

                    String data = JOptionPane.showInputDialog(null, "Digite a nova data da consulta: ", consultas.get(i).getData());
                    String prescricao = JOptionPane.showInputDialog(null, "Digite a nova prescricao da consulta: ", consultas.get(i).getPrescricao());
                    String validade = JOptionPane.showInputDialog(null, "Digite a nova validade da consulta: ", consultas.get(i).getValidade());

                    consultas.get(i).setCodigoConsulta(codigoConsultaNovo4);

                    consultas.get(i).setData(data);
                    consultas.get(i).setPrescricao(prescricao);
                    consultas.get(i).setValidade(validade);
                    consultas.get(i).setMedico(crm2);
                    consultas.get(i).setPaciente(codigoPaciente2);

                    JOptionPane.showMessageDialog(null, "Registro Editado com Sucesso", "Aviso", 1);

                }

            }

            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja editar outro registro\n8. Sim\n9. Não"));
            if (lista == 8) {
                deletarConsulta();
            } else if (lista == 9) {
                listarConsulta();
            }

        } else {

            menu();

        }

    }
    //fim - Consulta------------------------------------------------------------------------------------------------------------

    //nota ---------------------------------------------------------------------------------------------------------------------
    public static void notaConsulta() { // Metodo para nota das consultas

        int lista = 1;

        do {
            acho = 0;
            codigoNota = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o código da nota"));
            if (notas.size() > 0) {
                for (int i = 0; i < notas.size(); i++) {
                    if (codigoNota == notas.get(i).getCodigoNota()) {
                        acho = 1;
                    }
                }
            }
            if (acho == 1) {
                JOptionPane.showMessageDialog(null, "A nota já foi cadastrada", "Aviso", 1);
            }
        } while (acho == 1);

        int codigoConsulta2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o código consulta"));
        int nota2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a nota"));

        notas.add(new Nota(codigoNota, codigoConsulta2, nota2));

        lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja avaliar outra cunsulta?\n5. Sim\n7. Não"));
        if (lista == 5) {
            notaConsulta();
        } else if (lista == 7) {
            menu();
        }
    }

    public static void listarNota() { // Metodo para listar as notas da consultas

        String codigo4 = " Consulta: ";
        String codigo3 = "";

        //codigo da nota
        String codigo5 = " Codigo Nota: ";
        String codigo6 = "";
        //fim - codigo da nota
        String nota5 = "";
        //nota --------------

        //fim - nota
        String linha3 = "";
        String nomePacinte3 = "";
        String nomeMedico3 = "";

        if (notas.size() > 0) {

            //for consulta------------------------------------------------------
            for (int a = 0; a < notas.size(); a++) {

                //For consulta o sistema irar percorrer todas a lista da consulta ------------------------------------
                for (int i = 0; i < consultas.size(); i++) {

                    codigo6 = Integer.toString(notas.get(i).getCodigoNota());
                    nota5 = Integer.toString(notas.get(i).getNota());

                    if (consultas.get(i).getCodigoConsulta() == notas.get(a).getCodigoConsulta()) {

                        codigo3 = Integer.toString(consultas.get(i).getCodigoConsulta());

                        for (int b = 0; b < pacientes.size(); b++) {  //For paciente o sistema irar percorrer todas a lista dos pacientes

                            int numeroCpf3 = (consultas.get(i).getPaciente()); // irar pegar todas as consultas dos pacientes

                            if (pacientes.get(b).getNumeroCpf() == numeroCpf3) { // irar fazer a verificação do paciente

                                nomePacinte3 = pacientes.get(b).getNomePaciente(); // irar adicionar a lista paciente o nome do paciente

                            }
                        }

                        for (int c = 0; c < medicos.size(); c++) {  //For medicos o sistema irar percorrer todas a lista do medico

                            int crm3 = (consultas.get(i).getMedico()); // irar pegar todas as consultas cadastradas pelo medico

                            if (medicos.get(c).getCrm() == crm3) { // irar fazer a verificação do medico

                                nomeMedico3 = medicos.get(c).getNomeMedico(); // irar adicionar uma nota ao nome do medico

                            }
                        }

                    }
                    //Monta a lista de registros do lista nota com as variaveis declarada
                    linha3 += codigo5 + codigo6 + " Nota:" + nota5 + codigo4 + codigo3 + " Medico: " + nomeMedico3 + " Paciente: " + nomePacinte3 + "\n";
                    //Atribui os valores da lista nota com a nota , nome do medico e nome do paciente
                }
                //FIM - for consulta------------------------------------
            }
            //Fim - nota ----------------------------------------------------------

            lista = Integer.parseInt(JOptionPane.showInputDialog(null, linha3 + "\n8. Deletar\n7. Sair"));
            if (lista == 8) {
                deletarNota();
            } else if (lista == 7) {
                menu();
            }

        } else {
            // opção informando que não consta nota cadstrada e se deseja cadastrar
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Não existe nenhuma nota cadastrada, deseja cadastrar?\n7. Sim\n8. Não"));
            if (lista == 7) { // se a opção do usuario for o 7 ele irar cadastrar uma nova nota para a consulta
                notaConsulta();
            } else if (lista == 8) { // se a opção do usuario for 8 ele irar retornar ao menu principal
                menu();
            }
        }
    }

    public static void deletarNota() { //Metodo para deletar a nota

        int codigoNota2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o codigo da nota a ser deletada:"));

        if (notas.size() > 0) {
            for (int i = 0; i < notas.size(); i++) {

                if (notas.get(i).getCodigoNota() == (codigoNota2)) {

                    notas.remove(i); // remove a notas adicionadas
                    JOptionPane.showMessageDialog(null, "Registro deletado com Sucesso", "Aviso", 1);

                }
            }
            //menu com a opção de deletar o registro
            lista = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja deletar outro registro\n1. Sim\n8. Não"));
            if (lista == 1) { // se a opção do usuario for 1 irar deletar a nota
                deletarNota();
            } else if (lista == 8) {
                listarNota();
            }

        } else {

            menu();

        }
    }
    //fim - nota -------------------------------------------------------------------------------------------------------------------

    public static void sair() { //Metodo para sair

        System.exit(1);

    }

    public static void cadastroUsuario() { //Metodo para cadastrar o Usuario e fazer o login no sistema

        //desclara as variaveis
        String userName;
        String password;

        String userName2;
        String password2;

        //opcao 
        if (usuarios.size() == 0) {
            //pega os valores
            userName = JOptionPane.showInputDialog(null, "Cadastre o seu Nome para fazer o Login: ");
            password = JOptionPane.showInputDialog(null, "Cadastre seu Password para fazer o Login: ");
            //Fim - pega os valores das variaveis

            //adiciona os valores no arraylist usuarios
            usuarios.add(new Usuario(userName, password));
            cadastroUsuario();
        } else {

            //pega os valores das variaveis declarada
            userName2 = JOptionPane.showInputDialog(null, "Entre com o seu Nome cadastrado: ");
            password2 = JOptionPane.showInputDialog(null, "Entre com o seu Password cadastrado: ");
            //fim - pega os valores
            //adiciona os valores no arraylist logins
            logins.add(new Login(userName2, password2));

        }

    }
}
