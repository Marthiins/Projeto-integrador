/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastroconsultorio;

/**
 *
 * @author User
 */
public class Consulta {
    
    private Integer codigoConsulta;
    private Integer medico;
    private Integer paciente;
    private String Data;
    private String validade;
    private String prescricao;
     private String valorConsulta;


public Consulta(){

}

    public Consulta(Integer codigoConsulta, Integer medico, Integer paciente, String Data, String validade, String prescricao, String valorConsulta) {
        this.codigoConsulta = codigoConsulta;
        this.medico = medico;
        this.paciente = paciente;
        this.Data = Data;
        this.validade = validade;
        this.prescricao = prescricao;
        this.valorConsulta = valorConsulta;
    }

    public Integer getCodigoConsulta() {
        return codigoConsulta;
    }

    public void setCodigoConsulta(Integer codigoConsulta) {
        this.codigoConsulta = codigoConsulta;
    }

    public Integer getMedico() {
        return medico;
    }

    public void setMedico(Integer medico) {
        this.medico = medico;
    }

    public Integer getPaciente() {
        return paciente;
    }

    public void setPaciente(Integer paciente) {
        this.paciente = paciente;
    }

    public String getData() {
        return Data;
    }

    public void setData(String Data) {
        this.Data = Data;
    }

    public String getValidade() {
        return validade;
    }

    public void setValidade(String validade) {
        this.validade = validade;
    }

    public String getPrescricao() {
        return prescricao;
    }

    public void setPrescricao(String prescricao) {
        this.prescricao = prescricao;
    }

    public String getValorConsulta() {
        return valorConsulta;
    }

    public void setValorConsulta(String valorConsulta) {
        this.valorConsulta = valorConsulta;
    }


}