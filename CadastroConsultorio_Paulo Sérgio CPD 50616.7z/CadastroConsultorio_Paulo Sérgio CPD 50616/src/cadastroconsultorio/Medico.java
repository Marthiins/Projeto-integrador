/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastroconsultorio;

/**
 *
 * @author User
 */
public class Medico {

   
    private Integer crm;
    private String nomeMedico;
    private String especializacao;
    private String nacionalidade;
    private String sexo;
    private String idade;
     private String telefone;
      private String email;

    public Medico(){

    }

    public Medico(Integer crm, String nomeMedico, String especializacao, String nacionalidade, String sexo , String idade, String telefone,String email  ){

        this.crm=crm;
        this.nomeMedico=nomeMedico;
        this.especializacao=especializacao;
        this.nacionalidade=nacionalidade;
        this.sexo=sexo;
        this.idade=idade;
        this.telefone=telefone;
        this.email=email;
    }

    Medico(Integer crm, Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Integer getCrm() {
        return crm;
    }

    public void setCrm(Integer crm) {
        this.crm = crm;
    }

    public String getNomeMedico() {
        return nomeMedico;
    }


    public void setNomeMedico(String nomeMedico) {
        this.nomeMedico = nomeMedico;
    }

     public String getEspecializacao() {
        return especializacao;
    }

    public void setEspecializacao(String especializacao) {
        this.especializacao = especializacao;
    }
        public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }
     
    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }
    
    public boolean contains(Integer codigo) {
        // TODO Auto-generated method stub
        return false;
 
   
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    

}