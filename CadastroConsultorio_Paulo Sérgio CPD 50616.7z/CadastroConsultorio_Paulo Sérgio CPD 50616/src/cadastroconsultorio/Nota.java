/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastroconsultorio;

/**
 *
 * @author Fernanda
 */
public class Nota {
    
    private int codigoNota;
    private int codigoConsulta;
    private int nota;
    
    public Nota(Integer codigoNota, Integer codigoConsulta, Integer nota){

        this.codigoNota=codigoNota;
        this.codigoConsulta=codigoConsulta;
        this.nota=nota;
        
    }

    Nota() {
        
    }

    public int getCodigoNota() {
        return codigoNota;
    }

    public void setCodigoNota(int codigoNota) {
        this.codigoNota = codigoNota;
    }

    public int getCodigoConsulta() {
        return codigoConsulta;
    }

    public void setCodigoConsulta(int codigoConsulta) {
        this.codigoConsulta = codigoConsulta;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
    
}
