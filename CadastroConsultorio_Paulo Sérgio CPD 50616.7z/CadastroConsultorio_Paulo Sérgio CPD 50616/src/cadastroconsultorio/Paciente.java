/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastroconsultorio;

/**
 *
 * @author User
 */
public class Paciente {

    private Integer numeroCpf;
    private String nomePaciente;
    private String rg;
    private String sexo;
    private String idade;
    private String tipoDoenca;
    private String endereco;
    private String cidade;
    private String telefone;
    private String email;

    public Paciente() {

    }

    public Paciente(Integer numeroCpf, String nomePaciente, String rg, String sexo, String idade, String tipoDoenca, String endereco, String cidade,String telefone, String email) {
        this.numeroCpf = numeroCpf;
        this.nomePaciente = nomePaciente;
        this.rg = rg;
        this.sexo = sexo;
        this.idade = idade;
        this.tipoDoenca = tipoDoenca;
        this.endereco = endereco;
        this.cidade = cidade;
        this.telefone = telefone;
        this.email = email;
    }

    public Integer getNumeroCpf() {
        return numeroCpf;
    }

    public void setNumeroCpf(Integer numeroCpf) {
        this.numeroCpf = numeroCpf;
    }

    public String getNomePaciente() {
        return nomePaciente;
    }

    public void setNomePaciente(String nomePaciente) {
        this.nomePaciente = nomePaciente;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getTipoDoenca() {
        return tipoDoenca;
    }

    public void setTipoDoenca(String tipoDoenca) {
        this.tipoDoenca = tipoDoenca;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
